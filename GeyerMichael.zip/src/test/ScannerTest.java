package test;
/**
 * Tests related to the havaBol.Scanner
 * 
 * @author ckw273
 *
 */
public class ScannerTest {

}
